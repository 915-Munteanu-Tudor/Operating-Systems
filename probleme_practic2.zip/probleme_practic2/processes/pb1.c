// 1. Să se scrie un program C care creează un proces copil cu care comunică prin pipe. Procesul părinte citeşte de 
// la tastatură un număr natural şi îl trimite prin pipe procesului copil, iar procesul copil verifică şi afişează 
// dacă acest număr este par sau impar.

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char* argv[]) {
	int fd[2];
	int n;
	scanf("%d", &n);
	int res = pipe(fd);
	if (res == -1) {
		perror("pipe() error: ");
		exit(EXIT_FAILURE);
	}
	int pid = fork();
	if (pid == -1) {
		perror("fork() error:");
		exit(EXIT_FAILURE);
	}
	if (pid == 0) {
		close(fd[0]);
		if (n % 2 == 0) {
			printf("Numarul este par\n");
		}
		else {
			printf("Numarul este impar\n");
		}
		exit(0);
	}
	return 0;
	wait(0);
}

