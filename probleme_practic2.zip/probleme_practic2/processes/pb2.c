// 2. Să se scrie un program C care creează un proces copil cu care comunică prin pipe. Procesul părinte citeşte de 
// la tastatură un număr natural şi îl trimite prin pipe procesului copil, iar procesul copil verifică şi afişează 
// dacă acest număr este prim.


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
int main(int argc, char* argv[]) {
	int pd[2];
	int res = pipe(pd);
	if (res == -1) {
		perror("Pipe() error");
		exit(EXIT_FAILURE);
	}
	int pid = fork();
	if (pid == -1) {
		perror("fork() error");
		exit(EXIT_FAILURE);
	}
	if (pid == 0) {
		close(pd[1]);
		int n = 1;
		read(pd[0], &n, sizeof(int));
		int prime = 1;
		if (n < 2) {
			prime = 0;
		}
		else if (n == 2) {
			prime = 1;
		}
		else {
			for(int i = 2; i <= n / 2; i++) {
				if(n % i == 0) {
					prime = 0;
				}
			}
		}
		if (prime == 0) {
			printf("IN CHILD ---> Numarul citit %d nu este prim\n", n);
		} else {
			printf("IN CHILD ---> Numarul citit %d este prim\n", n);
		}
		close(pd[0]);
		exit(EXIT_SUCCESS);
	}
	close(pd[0]);
	int n = 1;
	printf("Introduceti numarul: ");
	scanf("%d", &n);
	write(pd[1], &n, sizeof(int));
	sleep(1);
	int status;
	wait(&status);
	close(pd[0]);
	return 0;
}
