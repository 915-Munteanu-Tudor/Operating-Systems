#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
	printf("A %d %d\n", getppid(), getpid());
	if (fork() == 0) {
		printf("B %d %d\n", getppid(), getpid());
		if (fork() == 0) {
			printf("C %d %d\n", getppid(), getpid());
			if (fork() == 0) {
				printf("D %d %d\n", getppid(), getpid());
				exit(0);
			}
			printf("waiting 1\n");
			wait(0);
			printf("exiting 1\n");
			exit(0);
		}
		printf("waiting 2\n");
		wait(0);
		printf("exiting 2\n");
		exit(0);
	}
	printf("waiting 3\n");
	wait(0);
	printf("exiting 3\n");
	return 0;
}
