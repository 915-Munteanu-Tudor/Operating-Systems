 #include <stdio.h>
#include <unistd.h>
#include <stdlib.h> //system

int main() {
	//execl("/bin/ls", "/bin/ls", "-l", NULL);
	//execlp("ls", "ls", "-l", NULL);
	//execl("/bin/ls", "/bin/ls", "-l", "p1.c", "exec1.c", "fork1.c", "xx", NULL);
	//execl("/bin/ls", "/bin/ls", "-l", "*.c", NULL); // /bin/ls: cannot access '*.c': No such file or directory 
	system("ls -l *.c");
	return 0;
}

