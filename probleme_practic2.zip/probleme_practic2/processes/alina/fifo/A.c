#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

int main() {
	char* fifo1 = "./fifo1";
	int res = mkfifo(fifo1, 0666);
	if (res == -1) {
		perror("mkfifo error");
		exit(EXIT_FAILURE);
	}
	int fd = open(fifo1, O_WRONLY);
	if (fd == -1) {
		perror("Fifo error");
		exit(EXIT_FAILURE);
	}
	int n = 1;
        while(n > 0) {
                printf("Give me a number: ");
                scanf("%d", &n);
                write(fd, &n, sizeof(int));
        }
	close(fd);
	unlink(fifo1);
	return 0;
}
