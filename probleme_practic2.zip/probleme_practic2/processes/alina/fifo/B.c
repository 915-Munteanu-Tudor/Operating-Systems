#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
        int p1 = fork();
	if (p1 == -1) {
		perror("eroare fork");
		exit(EXIT_FAILURE);
	} else if (p1 == 0) {
		char* fifo1 = "./fifo1";
	        int fd = open(fifo1, O_RDONLY);
       		if (fd == -1) {
                	perror("Fifo doesn't exist");
                	exit(EXIT_FAILURE);
        	}
		int n = 1, sum = 0;
       		while(n > 0) {
                	read(fd, &n, sizeof(int));
                	sum = sum + n;
        	}
		unlink(fifo1);
		int p[2];
		int res = pipe(p);
		if (res == -1) {
			perror("pipe error");
			exit(EXIT_FAILURE);
		}
		write(p[1], &sum, sizeof(int));
		int p2 = fork();
		if (p2 == -1) {
			perror("eroare fork");
			exit(EXIT_FAILURE);
		} else if (p2 == 0) {
			close(p[1]);
			int sum;
			read(p[0], &sum, sizeof(int));
			for(int d = 1; d <= sum; d++) {
				if (sum % d == 0) {
					printf("%d ", d);
				}
			}
			close(p[0]);
			exit(EXIT_SUCCESS);
		}
		close(p[0]);
		close(p[1]);
		wait(0);
	}
	wait(0);
	return 0;
}
