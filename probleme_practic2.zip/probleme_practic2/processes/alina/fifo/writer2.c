#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>

int main() {
	char* fifo1 = "./fifo1";
	int res = mkfifo(fifo1, 0666);
	if (res == -1) {
		perror("mkfifo error");
		exit(EXIT_FAILURE);
	}
	
