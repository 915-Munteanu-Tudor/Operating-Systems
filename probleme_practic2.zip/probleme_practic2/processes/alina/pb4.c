#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

int main(int argc, char* argv[]) {
	int i, pid;
	// char argvFiu[200];
	for (i = 1; i < argc; i++) {
		pid = fork();
		if (pid == 0) {
			// strcpy(argvFiu, argv[i]);
			// strcat(argvFiu, ".CAPIT");
			execl("./capit.sh", "./capit.sh", argv[i], NULL);
			printf("Error\n");
			exit(1);
		} else {
			printf("Parent, launched child: %d ...> %s \n", pid, argv[i]);
		}
	}
	for (i = 1; i < argc; i++) {
		wait(0);
	}
	printf("Launched simultaneously %d processes for capitalisation\n", argc-1);
	return 0;
}
