#include <stdio.h>
#include <unistd.h>
int main() {
	char* argv[3];
	argv[0] = "/bin/ls";
	argv[1] = "-l";
	argv[2] = NULL;
	execv("/bin/ls", argv);
	return 0;
}
