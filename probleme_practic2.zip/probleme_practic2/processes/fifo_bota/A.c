#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>

#define MAX_BUFFER 50

int main() {
	char* fifo_a2b = "./fifo_a2b";
	int res = mkfifo(fifo_a2b, 0666);
	if (res == -1) {
		perror("mkfifo error");
		exit(EXIT_FAILURE);
	}
	int fd = open(fifo_a2b, O_WRONLY);
	if (fd == -1) {
		perror("Fifo doesn't exist");
		exit(EXIT_FAILURE);
	}
	char s[MAX_BUFFER] = "\0";
	printf("Give me a string: ");
	scanf("%s", s);
	int len;
	while(strcmp(s, "stop") != 0) {
		len = strlen(s);
		write(fd, &len, sizeof(int));
		write(fd, s, strlen(s) * sizeof(char));
		printf("Give me a string: ");
		scanf("%s", s);
	}
	len = -1;
	write(fd, &len, sizeof(int));
	write(fd, s, sizeof(char));
	close(fd);
	unlink(fifo_a2b);
	return 0;
}

