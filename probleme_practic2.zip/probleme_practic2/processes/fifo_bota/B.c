#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

#define MAX_BUF 50

int main() {
	char* fifo_a2b = "./fifo_a2b";
	char* fifo_b2c = "./fifo_b2c";
	int res = mkfifo(fifo_b2c, 0666);
	if (res == -1) {
		perror("mkfifo error");
		exit(EXIT_FAILURE);
	}
	int fd = open(fifo_a2b, O_RDONLY);
	if (fd == -1) {
		perror("Fifo doesn't exist");
		exit(EXIT_FAILURE);
	}
	int fd2 = open(fifo_b2c, O_WRONLY);
	if (fd2 == -1) {
		perror("Fifo doesn't exist");
		exit(EXIT_FAILURE);
	}
	int len = 0;
	char s[MAX_BUF] = "\0";
	int V[26];
	int i;
	for(i = 0; i < 26; i++) {
		V[i] = 0;
	}
	read(fd, &len, sizeof(int));
	read(fd, s, len * sizeof(char));
	for(i = 0; i < len; i++) {
        	V[s[i] - 97]++;
	}
	while(len > 0) {
		printf("The string is: %s\n", s);
		read(fd, &len, sizeof(int));
		read(fd, s, len * sizeof(char));
		for(i = 0; i < len; i++) {
			V[s[i] - 97]++;
		}
	}
	for(i = 0; i < 26; i++) {
		printf("%c ", 97+i);
	}
	printf("\n");
	for(i = 0; i < 26; i++) {
		printf("%d ", V[i]);
		write(fd2, &V[i], sizeof(int));
	}
	close(fd);
	close(fd2);
	return 0;
}
