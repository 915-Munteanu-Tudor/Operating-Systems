#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

#define MAX_BUF 50

int main() {
        char* fifo_b2c = "./fifo_b2c";
	int fd = open(fifo_b2c, O_RDONLY);
	if (fd == -1) {
		perror("Fifo doesn't exist");
		exit(EXIT_FAILURE);
	}
	int i;
	int sum = 0;
	int x;
	for(i = 0; i < 26; i++) {
		read(fd, &x, sizeof(int));
		sum += x;
	}
	printf("\nSuma este: %d", sum);
	close(fd);
	return 0;
}
