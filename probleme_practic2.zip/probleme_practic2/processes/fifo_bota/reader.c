#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

#define MAX_BUF 1024

int main() {
	char* fifo1 = "./fifo1";
	int fd = open(fifo1, O_RDONLY);
	if (fd == -1) {
		perror("Fifo doesn't exist");
		exit(EXIT_FAILURE);
	}
	int n = 1;
	//read(fd, &n, sizeof(int));
	while(n > 0) {
		read(fd, &n, sizeof(int));
		printf("The number is: %d\n", n);
	}
	//char buf[MAX_BUF];
	//read(fd, buf, MAX_BUF);
	//printf("Message: %s\n", buf);
	close(fd);
	return 0;
}
