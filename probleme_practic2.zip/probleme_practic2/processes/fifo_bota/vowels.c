#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

int main() {


int p2a[2]; // pipe parent to child
int p2b[2]; // pipe child to parent
int a2p[2];
int b2p[2];

int res1 = pipe(p2a);
if (res1 == -1) {
	perror("pipe error");
	exit(EXIT_FAILURE);
}
int res2 = pipe(p2b);
if (res2 == -1) {
        perror("pipe error");
        exit(EXIT_FAILURE);
}

int res3 = pipe(a2p);
if (res3 == -1) {
        perror("pipe error");
        exit(EXIT_FAILURE);
}

int res4 = pipe(b2p);
if (res4 == -1) {
        perror("pipe error");
        exit(EXIT_FAILURE);
}

int a = fork();
int b = fork();
if (a == -1) {
	perror("fork error");
	exit(EXIT_FAILURE);
} else if (a == 0) {
	printf("sunt in a");
	char c = '\0';
	read(p2a[0], &c, sizeof(char));
	write(a2p[1], &c, sizeof(char));
	close(a2p[1]);
}

if (b == -1) {
        perror("fork error");
        exit(EXIT_FAILURE);
} else if (b == 0) {
	printf("sunt in b");
        char c = '\0';
        read(p2b[0], &c, sizeof(char));
        write(b2p[1], &c, sizeof(char));
	close(b2p[1]);
}

char s1[10] = "\0";
printf("Dati un caracter: ");
scanf("%s", s1);
char c = s1[0];
while (c != '\0') {
	printf("Caracterul este %c ", c);
	if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
		printf("vocala");
		write(p2a[1], &c, sizeof(char));
	}
	else if (c == '!') {
		break;
	}
	else {
		printf("consoana");
		write(p2b[1], &c, sizeof(char));
	}
	s1[0] = '\0';
	c = '\0';
	printf("Dati un caracter: ");
	scanf("%s", s1);
	c = s1[0];
}
while (0 < read(a2p[0], &c, sizeof(char))) {
	printf("%c ", c);
}
/*close(p2a[0]);
close(p2b[0]);
close(a2p[0]);
close(b2p[0]);
close(p2a[1]);
close(p2b[1]);
close(a2p[1]);
close(b2p[1]);*/
wait(0);
wait(0);
return 0;
}
