/* creeaza N threaduri (N - linia de comanda) si dau ca argument fiecarui thread doua stringuri citite de la
tastatura
	-> threadurile:
		- verifica daca primul string e substring in al doilea
		- daca e, il adauga la o lista globala de perechi de stringuri
	-> alt thread:
		- sorteaza lista de perechi alfabetic dupa stringul cel mai lung din perechi
		- trebuie sa fie creat inainte ca celelalte n threaduri sa dea join in main
	-> main:
		- printeaza variabila globala
! threadurile tb sa fie alocate dinamic */

#include <stdlib.h>
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <string.h>

#define MAX_SIZE 50

pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;
pthread_barrier_t barrier;

pthread_t* t;
pthread_t* u;

struct perechi {
	char* s1;
	char* s2;
};

struct perechi* lista;
int nr = 0;

void* f(void* a) {
	struct perechi k = *(struct perechi*)a;
	free(a);
	char* ret;
	ret = strstr(k.s2, k.s1);
	if(ret != NULL) {
		pthread_mutex_lock(&mtx);
		nr++;
		lista = realloc(lista, nr * sizeof(struct perechi));
		lista[nr-1].s1 = malloc(MAX_SIZE * sizeof(char));
		lista[nr-1].s2 = malloc(MAX_SIZE * sizeof(char));
		strcpy(lista[nr-1].s1, k.s1);
		strcpy(lista[nr-1].s2, k.s2);
		pthread_mutex_unlock(&mtx);
	}
	pthread_barrier_wait(&barrier);
	return NULL;
}

void* sortare(void* a) {
	int i;
	int j;
	for(i = 0; i < nr - 1; i++) {
		for(j = i + 1; j < nr; j++) {
			if(strcmp(lista[i].s2, lista[j].s2) > 0) {
				struct perechi aux;
				aux.s1 = malloc(MAX_SIZE * sizeof(char));
				aux.s2 = malloc(MAX_SIZE * sizeof(char));
				strcpy(aux.s2, lista[i].s2);
				strcpy(aux.s1, lista[i].s1);
				strcpy(lista[i].s2, lista[j].s2);
				strcpy(lista[i].s1, lista[j].s1);
				strcpy(lista[j].s1, aux.s1);
				strcpy(lista[j].s2, aux.s2);
			}
		}
	}
	return NULL;
}

int main(int argc, char* argv[]) {
	int N = atoi(argv[1]);
	t = malloc(N * sizeof(pthread_t));
	u = malloc(sizeof(pthread_t));
	lista = malloc(sizeof(struct perechi));
	int i;
	pthread_barrier_init(&barrier, NULL, N);
	for(i = 0; i < N; i++) {
		struct perechi* p = malloc(sizeof(struct perechi));
		p->s1 = malloc(MAX_SIZE * sizeof(char));
		p->s2 = malloc(MAX_SIZE * sizeof(char));
		scanf("%s", p->s1);
		scanf("%s", p->s2);
		pthread_create(&t[i], NULL, f, p);
	}
	pthread_create(&u[0], NULL, sortare, lista);
	for(i = 0; i < N; i++) {
		pthread_join(t[i], NULL);
	}
	pthread_barrier_destroy(&barrier);
	printf("\n");
	for(i = 0; i < nr; i++) {
		printf("%s %s\n", lista[i].s1, lista[i].s2);
	}
	return 0;
}
