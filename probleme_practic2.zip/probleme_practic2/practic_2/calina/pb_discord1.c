/* Creaza n threaduri(n la linia de comanda)
-fiecare thread primeste un index ca argument
-fiecare va genera un nr aleator a intre 1 si 10 si il va adauga la o variabila globala suma
-dupa ce toate threadurile au adaugat nr a in suma fiecare thread va genera alt nr aleator b ntre 1 si 15
-fieare thread va scadea nr b din suma doar daca suma este mai mare sau egala cu nr b
-fiecare thread va afisa indexul propriu, ambele nr generate si daca a reusit sau nu sa scada nr b din suma
-dupa ce toate threadurile se incheie, procesul principal va afisa valoarea sumei */

#include <stdlib.h>
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <string.h>

pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;
pthread_barrier_t barrier;
int suma = 0;

void* f(void* a) {
	int k = *(int*)a;
	free(a);
	//srand(time(NULL));
	int A = rand() % 10 + 1;
	pthread_mutex_lock(&mtx);
	suma += A;
	pthread_mutex_unlock(&mtx);
	//printf("%d\n", A);
	pthread_barrier_wait(&barrier);
	int B = rand() % 15 + 1;
	//printf("%d\n", B);
	int da = 0;
	pthread_mutex_lock(&mtx);
	if(suma >= B) {
		suma-= B;
		da = 1;
	}
	pthread_mutex_unlock(&mtx);
	printf("Am indexul %d si am generat numerele %d, %d\n", k, A, B);
	if(da == 1) {
		printf("Am scazut\n");
	}
	else {
		printf("Nu am scazut\n");
	}
	return NULL;
}

int main(int argc, char* argv[]) {
	int nthr = atoi(argv[1]);
	pthread_t t[nthr];
	pthread_barrier_init(&barrier, NULL, nthr);
	int i;
	for(i = 0; i < nthr; i++) {
		int* k = malloc(sizeof(int));
		*k = i;
		pthread_create(&t[i], NULL, f, k);
	}
	for(i = 0; i < nthr; i++) {
		pthread_join(t[i], NULL);
	}
	printf("\nSuma este: %d", suma);
	pthread_barrier_destroy(&barrier);
	return 0;
}
