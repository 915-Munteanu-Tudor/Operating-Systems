/* Write a program that creates N threads (command line argument), passing as an argument to each thread a number
and a string that are read from the keyboard.
- threads:
	- dynamically allocated
	- sleep for 2 seconds
	- add the number to one of the global lists of numbers multiples of 7 or not
	- store each string in a global array of strings
- main:
	- prints at the end the values of the global variables
! No more than 4 threads are running at the same time !
! no memory leaks ! */


#include <stdlib.h>
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <string.h>

#define N 4
#define SLEEP 2
#define OMIE 1000
#define MAX_CUVANT 20

struct nrstr{
	int nr;
	char* str;
};

pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
pthread_t* t;
int mul7[OMIE];
int numul7[OMIE];
int multipli = 0;
int nmultipli = 0;
char** strings;
int stringuri = 0;
int libere = 4;
void* f(void* a) {
	pthread_mutex_lock(&mtx);
	libere--;
	pthread_mutex_unlock(&mtx);
	struct nrstr k = *(struct nrstr*)a;
	//free(((struct nrstr*)a)->nr);
	free(a);
	//printf("Numarul e: %d", k.nr);
	//printf("Stringul e: %s", k.str);
	printf("Libere: %d\n", libere);
	while(libere == 0) {
		pthread_mutex_lock(&mtx);
		pthread_cond_wait(&cond, &mtx);
		pthread_mutex_unlock(&mtx);
		pthread_cond_signal(&cond);
	}
	sleep(SLEEP);
	if(k.nr % 7 == 0) {
		pthread_mutex_lock(&mtx);
		mul7[multipli] = k.nr;
		multipli++;
		pthread_mutex_unlock(&mtx);
	}
	else {
		pthread_mutex_lock(&mtx);
		numul7[nmultipli] = k.nr;
		nmultipli++;
		pthread_mutex_unlock(&mtx);
	}
	pthread_mutex_lock(&mtx);
	strings[stringuri] = malloc(strlen(k.str)*sizeof(char));
	strings[stringuri] = k.str;
	stringuri++;
	libere++;
	pthread_mutex_unlock(&mtx);
	return NULL;
}

int main(int argc, char* argv[]) {
	int nthr = atoi(argv[1]);
	t =(pthread_t*) malloc(nthr*sizeof(pthread_t));
	strings = malloc(nthr * sizeof(char*));
	int i;
	for(i = 0; i < nthr; i++) {
		struct nrstr* citit;
		citit = malloc(sizeof(struct nrstr));
		citit->str = malloc(MAX_CUVANT * sizeof(char));
		printf("Dati un numar: ");
		scanf("%d", &citit->nr);
		printf("Dati un string: ");
		scanf("%s", citit->str);
		pthread_create(&t[i], NULL, f, citit);
		//free(citit);
	}
	for(i = 0; i < nthr; i++) {
		pthread_join(t[i], NULL);
	}
	printf("\nMultiplii de 7:\n");
	for(i = 0; i < multipli; i++) {
		printf("%d ", mul7[i]);
	}
	printf("\nNemultiplii de 7:\n");
	for(i = 0; i < nmultipli; i++) {
		printf("%d ", numul7[i]);
	}
	printf("\n Stringurile sunt:\n");
	for(i = 0; i < stringuri; i++) {
		printf("%s ", strings[i]);
	}
	for(i = 0; i < stringuri; i++) {
		free(strings[i]);
	}
	free(strings);
	free(t);
	return 0;
}

