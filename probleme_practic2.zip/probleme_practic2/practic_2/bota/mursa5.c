/* 5. Vom create N thread-uri considerate consumatori, si M thread-uri considerate producatori.
    Un producator va insera un numar de X mesaje (pot fi orice, numere, charactere etc.) intr-o coada
    globala. De fiecare data cand coada se umple (adica atinge o limita L) producatorii vor trebui sa astepte
    pana cand se elibereaza cel putin un loc in coada.
    Un consumator va extrage mesaje din aceeasi coada globala. De fiecare data cand coada este goala, consumatorii
    vor trebui sa astepte pana cad se adauga cel putin un element.
    Se doreste implementarea acestor mecanisme de asteptare/notificare folosind variabile conditionale. */

#include <stdio.h>
#include <time.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>

// maximum nr of threads
#define N 100 // nr de consumatori
#define M 10 // nr de producatori
#define X 5 // cate pune un singur producator
#define L 40 // limita din coada

// shared variable
int numbers[60]; // coada
int full = 0; // = 1 -> coada e plina, = 0 -> coada e goala
int size = 0; // numarul de numere din coada
int generate = 0; // nr de numere generate pana acum de producatori

// lock object
pthread_cond_t cv = PTHREAD_COND_INITIALIZER;
pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;

void* f1 (void* a) {
        int i = size;
        srand(time(NULL));
	int nr = X;
        while(nr > 0 && generate < M*X) {
                pthread_mutex_lock(&mtx);
		while(size == L) {
			printf("PRODUCATOR: Coada e plina si astept\n");
			pthread_cond_wait(&cv, &mtx);
		}
                numbers[i] = rand() % 255 + 1;
          	printf("PRODUCATOR: Am pus numarul %d\n", numbers[size]);
		size++;
		generate++;
		pthread_cond_signal(&cv);
                pthread_mutex_unlock(&mtx);
        	i++;
		nr--;
	}
        return NULL;
}

void* f2 (void* a) {
	while(1) {
		pthread_mutex_lock(&mtx);
		printf("size: %d\n", size);
		while(size == 0) {
			printf("CONSUMATOR: Coada e goala si astept\n");
			printf("generate: %d\n", generate);
			if(generate == M * X) {
				printf("sunt aici\n");
				pthread_cond_signal(&cv);
				pthread_mutex_unlock(&mtx);
				return NULL;
			}
			pthread_cond_wait(&cv, &mtx);
		}
		printf("CONSUMATOR: Am scos numarul %d\n", numbers[size]);
		size--;
                pthread_cond_signal(&cv);
                pthread_mutex_unlock(&mtx);
        }
        return NULL;
}

int main(int argc, char* argv[]) {
        int i;
	pthread_t prod[M];
        pthread_t cons[N];
        for(i = 0; i < M; i++) {
                pthread_create(&prod[i], NULL, f1, NULL);
        }
	for(i = 0; i < N; i++) {
		pthread_create(&cons[i], NULL, f2, NULL);
	}
        for(i = 0; i < N; i++) {
                pthread_join(cons[i], NULL);
        }
	for(i = 0; i < M; i++) {
		pthread_join(prod[i], NULL);
	}
        return 0;
}
