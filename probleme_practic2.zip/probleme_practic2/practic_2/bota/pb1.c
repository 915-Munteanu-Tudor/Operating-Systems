#include <stdio.h>
#include <time.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>

// maximum nr of threads
#define MAX_SIZE 100000
#define MAX_NUM 200

// shared variable
int numbers[MAX_SIZE];
int sum = 0;
int full = 0; // buffer gol

// lock object
pthread_cond_t cv = PTHREAD_COND_INITIALIZER;
pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;
// thread start routine

void* f1 (void* a) {
        int N = *(int*)a;
        free(a);
        //sleep(5);
        int i;
        srand(time(NULL));
        for(i = 0; i < N; i++) {
                pthread_mutex_lock(&mtx);
                numbers[i] = rand() % 255 + 1;
                pthread_cond_signal(&cv);
                pthread_mutex_unlock(&mtx);
        }
        full = 1;
        return NULL;
}

void* f2 (void* a) {
        int k = *(int*)a;
        free(a);
        int i;
        int sum_invecinate = 0;
        int min = k + MAX_NUM;
        int max = min + MAX_NUM;
        for(i = min; i < max - 1; i++) {
                pthread_mutex_lock(&mtx);
                while(full == 0) {
                        pthread_cond_wait(&cv, &mtx);
		}
		if(numbers[i] % 11 == 0 && numbers[i+1] % 11 == 0) {
                        sum_invecinate += numbers[i] + numbers[i+1];
                        if(sum_invecinate > sum) {
                                sum = sum_invecinate;
                        }
                }
                pthread_cond_signal(&cv);
                pthread_mutex_unlock(&mtx);
        }
        return NULL;
}

int main(int argc, char* argv[]) {
        int N = 0;
        printf("Dati N: ");
        scanf("%d", &N);

        // creez threadul producator
        pthread_t t1;
        int* n = (int*) malloc(sizeof(int));
        *n = N;
        pthread_create(&t1, NULL, f1, n);
        // calculez numarul de threaduri de tip consumator
        int nthr = (int)(N / MAX_NUM);
        int i;
        pthread_t t2[nthr];
        for(i = 0; i < nthr; i++) {
                int* k = (int*) malloc (sizeof(int));
                *k = i;
                pthread_create(&t2[i], NULL, f2, k);
        }
        pthread_join(t1, NULL);
        for(i = 0; i < nthr; i++) {
                pthread_join(t2[i], NULL);
        }
        printf("Suma este: %d", sum);
        return 0;
}


