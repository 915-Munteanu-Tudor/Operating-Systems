/* -> main:
        - primeste la linia de comanda cateva numere si stringuri.
	- Pentru fiecare argument creeaza un proces.
   -> procesul:
	- lanseaza un program C sau shell care verifica daca argumentul e un nr prim
	- daca e, trimite prin pipe in main numarul
	- daca e un string, trimite nr de caractere in main
	- altfel, trimite 0
   -> main:
	- calculeaza suma numerelor valide si o printeaza */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

int main(int argc, char* argv[]) {
	int i;
	int c2p[argc][2];
	int pid;
	for(i = 1; i < argc; i++) {
		int res = pipe(c2p[i]);
		if (res == -1) {
			printf("pipe error");
			exit(EXIT_FAILURE);
		}
		pid = fork();
		if (pid == -1) {
			perror("fork error");
			exit(EXIT_FAILURE);
		}
		if (pid == 0) {
			close(c2p[i][0]);
			dup2(c2p[i][1], 1);
			int n;
			n = atoi(argv[i]);
			if (n == 0) {
				int len = strlen(argv[i]);
				//printf("%s %d", argv[i], len);
				write(c2p[i][1], &len, sizeof(int));
				exit(EXIT_SUCCESS);
			}
			else {
				execl("./prim", "./prim", argv[i], NULL);
				//printf("%d Error\n", n);
				close(c2p[i][1]);
				exit(EXIT_FAILURE);
			}
		}
	}
	int s = 0;
	for (i = 1; i < argc; i++) {
		close(c2p[i][1]);
		int nr = 0;
		read(c2p[i][0], &nr, sizeof(int));
		if (nr == 0) {
			printf("The number is not prime\n");
		}
		else {
			printf("Received number %d\n", nr);
		}
		s += nr;
		close(c2p[i][0]);
	}
	for (i = 1; i < argc; i++) {
		wait(0);
	}
	printf("Sum is %d\n", s);
	return 0;
}
