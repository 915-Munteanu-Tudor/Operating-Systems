/* creeaza un proces copil.
 -> parintele:
	- genereaza un nr random intre 10 si 30 si creeaza un string de lungime N. Stringul o sa fie initializat
	cu caracterul a pe fiecare pozitie.
	- trimite copilului stringul
 -> copilul:
	- pt fiecare car din string genereaza un nr random intre 10 si 24 si il adauga la codul ascii al
	caracterului
	- trimite inapoi parintelui stringul modificat
 -> parintele:
	- printeaza N si stringul modificat de copil */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <time.h>

#define BUF_SIZE 31

int main(int argc, char* argv[]) {
	int p2c[2];
	int c2p[2];
	srand(time(NULL));
	char s[BUF_SIZE] = "\0";
	char s2[BUF_SIZE] = "\0";
	int res = pipe(p2c);

	if(res == -1) {
		perror("pipe error");
		exit(EXIT_FAILURE);
	}
	int res2 = pipe(c2p);
	if(res2 == -1) {
		perror("pipe error");
		exit(EXIT_FAILURE);
	}
	int pid = fork();
	if(pid == -1) {
		perror("fork error");
		exit(EXIT_FAILURE);
	}
	if(pid == 0) {
		close(p2c[1]);
		close(c2p[0]);
		char c = '\0';
		int index = 0;
		while(read(p2c[0], &c, sizeof(char)) > 0) {
			int nr = rand() % 25;
			if (nr < 10) {
				nr += 10;
			}
			c += nr;
			s[index] = c;
			index++;
		}
		write(c2p[1], s, index * sizeof(char));
		close(p2c[0]);
		close(c2p[1]);
		exit(EXIT_SUCCESS);
	}
	close(p2c[0]);
	close(c2p[1]);
	int N = rand() % 31;
	if(N < 10) {
		N += 10;
	}
	printf("N = %d\n", N);
	for(int i = 0; i < N; i++) {
		s[i] = 'a';
	}
	write(p2c[1], s, strlen(s)*sizeof(char));
	close(p2c[1]);
	read(c2p[0], s2, (N+1) * sizeof(char));
	printf("%s", s2);
	wait(0);
	return 0;
}
