#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char* argv[]) {
	int n = atoi(argv[1]);
	if (n < 2) {
		int len = 0;
		write(1, &len, sizeof(int));
		return 0;
	}
	else if (n == 2) {
                write(1, &n, sizeof(int));
		return 0;
	}
	else if (n % 2 == 0) {
		int len = 0;
                write(1, &len, sizeof(int));
		return 0;
	}
	int i;
	for (i = 3; i * i <= n; i += 2) {
		if (n % i == 0) {
			int len = 0;
	                write(1, &len, sizeof(int));
			return 0;
		}
	}
	write(1, &n, sizeof(int));
	return 0;
}
