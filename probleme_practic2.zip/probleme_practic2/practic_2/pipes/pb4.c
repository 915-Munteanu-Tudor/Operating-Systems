/* -> main:
	- creeaza 3 procese copil P1, P2, P3
   -> P1:
	- trimite fiecare argument de la linia de comanda catre P2
   -> P2:
	- primeste argumentele ca stringuri si incearca sa le converteasca in numere
	- le trimite la P3 daca se pot converti, altfel trimite 0
   -> P3:
	- primeste numerele, le printeaza
	- pt fiecare numar trimite la P1 0 daca nr este par si 1 daca nr e impar
   -> P1:
	- primeste numerele
	- pt fiecare valoare de 1 citeste un nou string (care poate fi un nr) pe care il trimite mai departe la P2
	si tot asa...
	- cand P1 primeste 3 zerouri consecutiv, toate procesele se termina */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

#define BUF_SIZE 50

int stop = 0;
int ant = 0;


int main(int argc, char* argv[]) {
	int p1p2[2], p2p3[2], p3p1[2];
	int res12 = pipe(p1p2);
	if (res12 == -1) {
		perror("pipe error");
		exit(EXIT_FAILURE);
	}
	int res23 = pipe(p2p3);
        if (res23 == -1) {
                perror("pipe error");
                exit(EXIT_FAILURE);
        }
	int res31 = pipe(p3p1);
        if (res31 == -1) {
                perror("pipe error");
                exit(EXIT_FAILURE);
        }
	int pid1 = fork();
	if (pid1 == -1) {
		perror("fork error");
		exit(EXIT_FAILURE);
	}
	if (pid1 == 0) {
		printf("aici1");
		/*close(p1p2[0]);
		close(p2p3[0]);
		close(p2p3[1]);
		close(p3p1[1]);*/
		int i;
		for(i = 1; i < argc; i++) {
			int len = strlen(argv[i]);
			write(p1p2[1], &len, sizeof(int));
			write(p1p2[1], argv[i], strlen(argv[i]) * sizeof(char));
		}

//		while(1) {
			int nr;
			read(p3p1[0], &nr, sizeof(int));
			if (nr == 1) {
				ant = 1;
				char s[BUF_SIZE] = "\0";
				printf("Introduceti un nou string: ");
				read(0, s, BUF_SIZE * sizeof(char));
				int len = strlen(s);

				write(p1p2[1], &len, sizeof(int));
				write(p1p2[1], s, strlen(s) * sizeof(char));
			}
			else {
				if (ant == 1) {
					stop = 1;
				}
				else {
					stop++;
				}
				if (stop == 3) {
					exit(EXIT_SUCCESS);
				}
			}
//		}
		//close(p1p2[1]);
		//close(p3p1[0]);
	}
	else {
		int pid2 = fork();
		if (pid2 == -1) {
			perror("fork error");
                	exit(EXIT_FAILURE);
		}
		if (pid2 == 0) {
			printf("aici2");
			/*close(p1p2[1]);
			close(p2p3[0]);
			close(p3p1[0]);
			close(p3p1[1]);*/
			int i;
			for(i = 1; i < argc; i++) {
				char s[BUF_SIZE] = "\0";
				int len = 0;
				read(p1p2[0], &len, sizeof(int));
				read(p1p2[0], s, len * sizeof(char));
				int val = atoi(s);
				write(p2p3[1], &val, sizeof(int));
			}
			//for(;;) {
				char s[BUF_SIZE] = "\0";
				int len = 0;
				read(p1p2[0], &len, sizeof(int));
				if (len == 0) {
					int val = -1;
					write(p2p3[1], &val, sizeof(int));
					exit(EXIT_SUCCESS);
				}
				read(p1p2[0], s, len * sizeof(char));
				int val = atoi(s);
				write(p2p3[1], &val, sizeof(int));
			//}
			//close(p1p2[0]);
			//close(p2p3[1]);
		}
		else {
			int pid3 = fork();
	                if (pid3 == -1) {
                        	perror("fork error");
                        	exit(EXIT_FAILURE);
                	}
                	if (pid3 == 0) {
				printf("aici3");
				/*close(p1p2[0]);
				close(p1p2[1]);
				close(p2p3[1]);
				close(p3p1[0]);*/
				int nr = 0, i;
				for(i = 1; i < argc; i++) {
					read(p2p3[0], &nr, sizeof(int));
					printf("%d ", nr);
					if(nr % 2 == 0) {
						int x = 0;
						write(p3p1[1], &x, sizeof(int));
					}
					else {
						int x = 1;
						write(p3p1[1], &x, sizeof(int));
					}
				}
				//for(;;) {
					read(p2p3[0], &nr, sizeof(int));
					if (nr == -1) {
						exit(EXIT_SUCCESS);
					}
                                        printf("%d ", nr);
                                        if(nr % 2 == 0) {
                                                int x = 0;
                                                write(p3p1[1], &x, sizeof(int));
                                        }
                                        else {
                                                int x = 1;
                                                write(p3p1[1], &x, sizeof(int));
                                        }
                                //}
				//close(p2p3[0]);
				//close(p3p1[1]);
                	}
		}
	}

	wait(0);
	wait(0);
	wait(0);
	return 0;
}
