/* primeste ca argument la linia de comanda un nr intreg N.
 -> parintele:
	- creeaza doua procese fiu
 -> fiii:
	- fiecare are un sir de frecvente pt cifrele din baza 10 si va genera N numere intregi aleatoare intre 100
	si 199
	- va actualiza sirul de frecvente al cifrelor in functie de cifrele continute de numerele generate
	- va printa fiecare nr generat
	- dupa ce a generat N numere aleatoare, trimite sirul de frecvente catre procesul parinte
 -> parintele:
	- va afisa un mesaj pt fiecare cifra indicand care proces fiu a obtinut frecventa mai mare */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>

int main(int argc, char* argv[]) {
	int N = atoi(argv[1]);
	srand(time(NULL));
	int c1p[2];
	int c2p[2];
	int res1 = pipe(c1p);
	if (res1 == -1) {
		perror("Pipe error");
		exit(EXIT_FAILURE);
	}
	int res2 = pipe(c2p);
	if (res2 == -1) {
		perror("Pipe error");
		exit(EXIT_FAILURE);
	}
	int pid1 = fork();
	if(pid1 == -1) {
		perror("Fork error");
		exit(EXIT_FAILURE);
	}

	if (pid1 == 0) {
		close(c1p[0]);
		int frecv[10];
		int i;
		for (i = 0; i < 10; i++) {
			frecv[i] = 0;
		}
		printf("CHILD 1: ");
		for (i = 0; i < N; i++) {
			int nr = rand() % 200;
			if (nr < 100) {
				nr += 100;
			}
			printf("%d ", nr);
			int c1 = nr % 10;
			frecv[c1]++;
			nr /= 10;
			int c2 = nr % 10;
			frecv[c2]++;
			nr /= 10;
			frecv[nr]++;
		}
		printf("\nFrequency array: ");
		for(i = 0; i < 10; i++) {
			printf("%d ", frecv[i]);
		}
		printf("\n");
		write(c1p[1], frecv, 10 * sizeof(int));
		close(c1p[1]);
	}
	else {
	int pid2 = fork();
        if(pid2 == -1) {
                perror("Fork error");
                exit(EXIT_FAILURE);
        }
	if (pid2 == 0) {
                close(c2p[0]);
                int frecv[10];
                int i;
		for (i = 0; i < 10; i++) {
			frecv[i] = 0;
		}
                printf("CHILD 2: ");
                for (i = 0; i < N; i++) {
                        int nr = rand() % 199;
			nr += 1;
                        if (nr < 100) {
                                nr += 100;
                        }
                        printf("%d ", nr);
                        int c1 = nr % 10;
                        frecv[c1]++;
                        nr /= 10;
                        int c2 = nr % 10;
                        frecv[c2]++;
                        nr /= 10;
                        frecv[nr]++;
                }
		printf("\nFrequency array: ");
		for(i = 0; i < 10; i++) {
			printf("%d ", frecv[i]);
		}
		printf("\n");
                write(c2p[1], frecv, 10 * sizeof(int));
                close(c2p[1]);
        }
	else {

	close(c1p[1]);
	close(c2p[1]);
	int frecv1[10];
	int frecv2[10];
	//read(c1p[0], frecv1, 10 * sizeof(int));
	//read(c2p[0], frecv2, 10 * sizeof(int));
	int i;
	for(i = 0; i < 10; i++) {
		read(c1p[0], &frecv1[i], sizeof(int));
		read(c2p[0], &frecv2[i], sizeof(int));
		if (frecv1[i] < frecv2[i]) {
			printf("%d - child 2\n", i);
		}
		else if (frecv1[i] > frecv2[i]) {
			printf("%d - child 1\n", i);
		}
		else {
			printf("%d - equal\n", i);
		}
	}
	close(c1p[0]);
	close(c2p[0]);
	wait(0);
	wait(0);
	return 0;
	}
	}
}

